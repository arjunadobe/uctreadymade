# Upgrade Compatibility Tool developer guide

Welcome to the Adobe Commerce Upgrade Compatibility Tool developer readme. See the [Run](https://devdocs.magento.com/upgrade-compatibility-tool/run.html) page to check necessary steps to use the Upgrade Compatibility Tool.

See the [Developer](https://devdocs.magento.com/upgrade-compatibility-tool/run.html) page for more information on technical details of the Upgrade Compatibility Tool.

See the [Error reference](https://devdocs.magento.com/upgrade-compatibility-tool/run.html) page for more information on all possible errors that the Upgrade Compatibility Tool can return.

## Upgrade Compatibility Tool packaging and distribution

To package and distribute the Upgrade Compatibility Tool, proceed with the following stages.

### Packaging

Step by step process:

 - Update version in composer.json. Increment Major, minor or patch version depending on the level of changes since the latest release.
 - Create package archive
 - Create new internal release on repo.magento.com
 - Upload package archive to the repo.magento.com
 - Update created release with external access

#### repo.magento.com access

To retrieve the access to repo.magento.com:
 - Ensure Adobe or Magento VPN is connected
 - Navigate to https://repo.magento.com/admin/access/request and submit request for necessary permissions
 - Notify the #repo slack channel for faster request processing

#### Creating package archive

To package the tool, execute `bin/package` command from the project root providing version as an argument.

For example for 1.0.0 version generation run:

```
bin/package 1.0.0
```

The package archive will be generated and save to `uct.zip` archive in the project root.

#### Creating a release

Go to `repo.magento.com -> Releases -> Core Releases -> (+)Add New` or navigate to https://repo.magento.com/admin/packagist/web/ceeerelease/create

Fill the form with the following information:

 - Name: magento/upgrade-compatibility-tool-VERSION
 - Availability Groups: Internal

> Example of a `create release`

![Create Release](images/createrelease.png)

#### Uploading package archive

Go to `repo.magento.com -> Packages -> Uploda Core M2 Version` or navigate to https://repo.magento.com/admin/upload_m2_version

Fill the form with the following information:

 - Extension package: `uct.zip`
 - Release: magento/upgrade-compatibility-tool-VERSION
 - Edition: EE

> Example of a `create release`

![Upload version](images/uploadversion.png)

#### Making release publicly available

Go to `repo.magento.com -> Releases -> Core Releases` and click `Edit` next to the created release (filter the grid by name if the release is not visible).

On the release edit form, update the "Availability Groups" field removing `Internal` and adding `External` instead.

![Set release as EXTERNAL](images/setreleaseasexternal.png)

#### Verification

To check that all was done correctly:

 - Verify package information on repo.magento.com
 - Install the new version of the package using composer and perform a basic test of the UCT commands

To verify published version go to `repo.magento.com -> Packages -> Versions` or navigate to https://repo.magento.com/admin/packagist/web/version/list and review the information in the grid.

![Version list](images/versions.png)

See [wiki](https://wiki.corp.magento.com/x/8wiiBw) for more information.

#### Update UCT in SWAT

 - Clone https://git.corp.adobe.com/magento-ceset/uct-worker/ repository
 - Run `composer update magento/upgrade-compatibility-tool` (update the version in composer.json for major version release)
 - Commit composer.lock file
 - Open a pull request

## Upgrade Compatibility Tool Tracking

Upgrade Compatibility Tool Tracking is a small AWS lambda done with GO. This lambda receives metrics from UCT and send it to CloudWatch.

### UCT Tracking develop and deploy

See [Upgrade Compatibility Tool tracking](https://github.com/magento-commerce/safe-upgrade-tool-tracking) for more information.

### Pre-commit hooks

To ensure code quality, it is recommended to set up a git pre-commit hook that will check changes every time they are
committed. This pre-hook script will take care of:

* Ensuring unit and integration tests pass.
* Running PHP Code sniffer with set of rules at [dev/tests/Static/ruleset.xml](dev/tests/Static/ruleset.xml).

To set up this hook in your local environment, just execute `git config core.hooksPath .githooks` from repository root.

## Additional resources

See the [Upgrade Compatibility Tool github wiki](https://github.com/magento/safe-upgrade-tool/wiki) for additional information and resources.

See the [M-Ray](https://github.com/magento-commerce/mray) library.

See the [API Index](https://github.com/magento-commerce/magento-api-index) library.
