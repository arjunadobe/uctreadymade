/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */

import GraphQLCompare from '../../../graphql-schema-compatibility/js/main.js';
import { test, expect, describe } from '@jest/globals';
import { buildSchema } from 'graphql';

let oldGraphqlSchema, newGraphqlSchema, expected;

oldGraphqlSchema = buildSchema(`
  type TestingNoChanges {
    id: String
    name: String
  }

  type Query {
    testingNoChanges(id: String): TestingNoChanges
  }
`);

newGraphqlSchema = buildSchema(`
  type TestingNoChanges {
    id: String
    name: String
  }

  type Query {
    testingNoChanges(id: String): TestingNoChanges
  }
`);

expected = [];

describe('Function getErrors', () => {
    test('it should return there are no breaking changes', () => {
        expect(GraphQLCompare.getCritical(oldGraphqlSchema, newGraphqlSchema)).toEqual(expected);
    });
});

describe('Function getWarnings', () => {
    test('it should return there are no warning changes', () => {
        expect(GraphQLCompare.getWarnings(oldGraphqlSchema, newGraphqlSchema)).toEqual(expected);
    });
});
