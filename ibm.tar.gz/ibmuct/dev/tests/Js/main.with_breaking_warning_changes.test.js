/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */

import GraphQLCompare from '../../../graphql-schema-compatibility/js/main.js';
import { test, expect, describe } from '@jest/globals';
import { buildSchema } from 'graphql';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

let oldGraphqlSchemaFile, oldGraphqlSchema, newGraphqlSchemaFile, newGraphqlSchema, expectedErrors, expectedWarnings;
const
    __dirname = path.dirname(fileURLToPath(import.meta.url)),
    LEVEL_CRITICAL = 1,
    LEVEL_WARNING = 3;


oldGraphqlSchemaFile = fs.readFileSync(
    __dirname + '/../Acceptance/_files/graphql_schemas/old_graphql_schema.graphqls',
    'utf-8'
);
newGraphqlSchemaFile = fs.readFileSync(
    __dirname + '/../Acceptance/_files/graphql_schemas/new_graphql_schema.graphqls',
    'utf-8'
);

oldGraphqlSchema = buildSchema(oldGraphqlSchemaFile);
newGraphqlSchema = buildSchema(newGraphqlSchemaFile);

expectedErrors = [
    {
        'description': 'TestingTypeRemoved was removed.',
        'severity': LEVEL_CRITICAL,
        'type': 'TYPE_REMOVED'
    },
    {
        'description': 'TypeCustom2 was removed.',
        'severity': LEVEL_CRITICAL,
        'type': 'TYPE_REMOVED'
    },
    {
        'description': 'TestingFieldRemoved.name was removed.',
        'severity': LEVEL_CRITICAL,
        'type': 'FIELD_REMOVED'
    },
    {
        'description': 'Query.testingArgs arg arg2 was removed.',
        'severity': LEVEL_CRITICAL,
        'type': 'ARG_REMOVED'
    },
    {
        'description': 'Query.testingArgs arg arg1 has changed type from Int to Float.',
        'severity': LEVEL_CRITICAL,
        'type': 'ARG_CHANGED_KIND'
    },
    {
        'description': 'A required arg arg3 on Query.testingArgs was added.',
        'severity': LEVEL_CRITICAL,
        'type': 'REQUIRED_ARG_ADDED'
    },
    {
        'description': 'TestingTypeChanged changed from an Input type to an Object type.',
        'severity': LEVEL_CRITICAL,
        'type': 'TYPE_CHANGED_KIND'
    },
    {
        'description': 'A required field name on input type TestingInputFieldAdded was added.',
        'severity': LEVEL_CRITICAL,
        'type': 'REQUIRED_INPUT_FIELD_ADDED'
    },
    {
        'description': 'TestingFieldChanged.test_field changed type from String to Int.',
        'severity': LEVEL_CRITICAL,
        'type': 'FIELD_CHANGED_KIND'
    },
    {
        'description': 'TestingRemovedInterface no longer implements interface TestingFieldChangedInterface.',
        'severity': LEVEL_CRITICAL,
        'type': 'IMPLEMENTED_INTERFACE_REMOVED'
    },
    {
        'description': 'VALUE_THREE was removed from enum type TestingEnum.',
        'severity': LEVEL_CRITICAL,
        'type': 'VALUE_REMOVED_FROM_ENUM'
    },
    {
        'description': 'TypeCustom2 was removed from union type TestingUnion.',
        'severity': LEVEL_CRITICAL,
        'type': 'TYPE_REMOVED_FROM_UNION'
    },
    {
        'description': 'testingDirectiveRemoved was removed.',
        'severity': LEVEL_CRITICAL,
        'type': 'DIRECTIVE_REMOVED'
    },
    {
        'description': 'A required arg url on directive testingDirectiveChanged was added.',
        'severity': LEVEL_CRITICAL,
        'type': 'REQUIRED_DIRECTIVE_ARG_ADDED'
    },
    {
        'description': 'name was removed from testingDirectiveChanged.',
        'severity': LEVEL_CRITICAL,
        'type': 'DIRECTIVE_ARG_REMOVED'
    },
    {
        'description': 'INTERFACE was removed from testingDirectiveChanged.',
        'severity': LEVEL_CRITICAL,
        'type': 'DIRECTIVE_LOCATION_REMOVED'
    },
    {
        'description': 'Repeatable flag was removed from testingDirectiveThatWasRepeatable.',
        'severity': LEVEL_CRITICAL,
        'type': 'DIRECTIVE_REPEATABLE_REMOVED'
    }
];

expectedWarnings = [
    {
        'description': 'Query.testing_value_default arg def has changed ' +
            'defaultValue from ["Testing"] to ["Testing default"].',
        'severity': LEVEL_WARNING,
        'type': 'ARG_DEFAULT_VALUE_CHANGE'
    },
    {
        'description': 'An optional arg arg4 on Query.testingArgs was added.',
        'severity': LEVEL_WARNING,
        'type': 'OPTIONAL_ARG_ADDED'
    },
    {
        'description': 'An optional field new_input on input type TestingInputFieldAdded was added.',
        'severity': LEVEL_WARNING,
        'type': 'OPTIONAL_INPUT_FIELD_ADDED'
    },
    {
        'description': 'TestingFieldRemovedInterface added to interfaces implemented by TestingFieldChanged.',
        'severity': LEVEL_WARNING,
        'type': 'IMPLEMENTED_INTERFACE_ADDED'
    },
    {
        'description': 'VALUE_FOUR was added to enum type TestingEnum.',
        'severity': LEVEL_WARNING,
        'type': 'VALUE_ADDED_TO_ENUM'
    },
    {
        'description': 'TestingTypeChanged was added to union type TestingUnion.',
        'severity': LEVEL_WARNING,
        'type': 'TYPE_ADDED_TO_UNION'
    }
];

describe('Function getCritical', () => {
    test('it should return there are breaking changes', () => {
        expect(GraphQLCompare.getCritical(oldGraphqlSchema, newGraphqlSchema)).toEqual(expectedErrors);
    });
});

describe('Function getWarnings', () => {
    test('it should return there are warning changes', () => {
        expect(GraphQLCompare.getWarnings(oldGraphqlSchema, newGraphqlSchema)).toEqual(expectedWarnings);
    });
});
