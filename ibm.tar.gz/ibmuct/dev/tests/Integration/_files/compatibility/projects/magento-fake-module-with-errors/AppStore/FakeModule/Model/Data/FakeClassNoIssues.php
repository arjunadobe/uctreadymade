<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\FakeModule\Model\Data;

use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Model\Product;

/**
 * Extended with Adobe Commerce class that is on Magento api and not deprecated
 * Implements with Adobe Commerce interface that is on Magento api and not deprecated
 */
class FakeClassNoIssues extends Product implements ProductInterface
{
    private const SKU = "1234";

    /**
     * @return string|null
     */
    public function getFakeClassSku()
    {
        return $this->_get(self::SKU);
    }

    /**
     * @param string $fakeClassSku
     * @return ProductInterface
     */
    public function setFakeClassSku($fakeClassSku)
    {
        return $this->setData(self::SKU, $fakeClassSku);
    }
}
