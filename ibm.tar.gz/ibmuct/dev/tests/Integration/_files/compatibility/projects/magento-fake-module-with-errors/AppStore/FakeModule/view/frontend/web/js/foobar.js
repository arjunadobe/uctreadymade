define([
	'editor',
	'settings',
	'jquery'
], function (editor, settings, $) {
	$('div').find('p').andSelf().addClass('border');

	editor.addMenuItem(name, settings);
});
