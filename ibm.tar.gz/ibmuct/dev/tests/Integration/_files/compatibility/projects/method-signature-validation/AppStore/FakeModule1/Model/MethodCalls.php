<?php
/**
 * Copyright 2022 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\FakeModule1\Model;

class MethodCalls
{
    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    private $repository;

    public function __construct(\Magento\Catalog\Api\ProductRepositoryInterface $repository)
    {
        $this->repository = $repository;
    }

    public function missingOptionalArguments($sku)
    {
        $this->repository->get($sku);
    }

    public function incorrectArgumentType(int $sku)
    {
        $this->repository->get($sku);
    }

    public function missingRequiredArguments()
    {
        $this->repository->get();
    }

    public function incorrectOptionalArgumentType(string $sku, int $editMode)
    {
        $this->repository->get($sku, $editMode);
    }

    public function multitypeExpected(string $sku, bool $editMode, int $storeId)
    {
        $this->repository->get($sku, $editMode, $storeId);
    }

    public function mixed(string $key, int $value)
    {
        $dataObject = new \Magento\Framework\DataObject();
        $dataObject->setData($key, $value);
    }

    /**
     * @param int|string|array $sku
     */
    public function multitypeActual($sku)
    {
        $this->repository->get($sku);
    }
}
