<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\FakeModule\Model;

use Magento\Catalog\Model\Product;
use Magento\Cms\Api\BlockRepositoryInterface;
use Magento\Cms\Model\Block;
use Magento\Framework\Search\Request\Query\Match;

class DataObjects
{
    public function __construct(Product $product, Block $block, BlockRepositoryInterface $repository)
    {
        $product->setDataObjectKey('value');
        $block->hasDataObjectKey('value');
        $repository->setNonExistingMethod('value');
    }

    public function matchSomething() 
    {
        $match = new Match('testmatch', 'TEST', 10);
        $match->getValue();
    }
}
