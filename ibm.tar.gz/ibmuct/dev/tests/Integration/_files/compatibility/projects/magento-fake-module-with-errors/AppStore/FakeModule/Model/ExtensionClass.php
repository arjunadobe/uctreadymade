<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\FakeModule\Model;

use Magento\Catalog\Api\Data\NotFoundExtension;
use Magento\Catalog\Api\Data\ProductExtension;

class ExtensionClassUseNotRecommended extends ProductExtension
{
}

class ExtensionClassNotExists extends NotFoundExtension
{
}
