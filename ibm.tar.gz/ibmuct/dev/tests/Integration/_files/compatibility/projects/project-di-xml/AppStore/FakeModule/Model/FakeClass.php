<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\FakeModule\Model;

use Magento\Catalog\Model\Product\Gallery\ImagesConfigFactoryInterface;

/**
 * Extended with Adobe Commerce class that is not on Magento api
 * Implements with Adobe Commerce interface that is not on Magento api
 */
class FakeClass extends Image implements ImagesConfigFactoryInterface
{
}
