<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\FakeModule\Model;

class ExtensionInterface implements \Magento\Catalog\Api\Data\ProductExtensionInterface
{
}
