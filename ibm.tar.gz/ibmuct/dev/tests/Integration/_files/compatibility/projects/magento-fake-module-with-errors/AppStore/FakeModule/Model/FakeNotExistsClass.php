<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\FakeModule\Model;

use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\Product\ClassNotExists;
use Magento\Framework\Option\ArrayInterface;

/**
 * Extended with Adobe Commerce class that does not exist any more
 * Implements with Adobe Commerce interface that does not exist any more
 */
class FakeNotExistsClass extends ClassNotExists implements ArrayInterface
{
    /**
     * @var Product $product
     */
    private $product;

    /**
     * Use constant and property that does not exist any more
     * Call method does not exist any more
     */
    public function thingsNotExist()
    {
        $notExistsConstant = Product::NOT_EXISTS_CONSTANT;

        $this->product->propertyNotExists;

        $this->product->methodNotExists();
    }
    
    public function toOptionArray(){
        return null;
    }
}
