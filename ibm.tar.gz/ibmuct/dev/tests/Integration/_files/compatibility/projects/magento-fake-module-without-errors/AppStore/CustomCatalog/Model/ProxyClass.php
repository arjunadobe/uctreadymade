<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\FakeModule\Model;

class ProxyClass
{
    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface\Proxy
     */
    private $proxy;

    public function __construct()
    {
        $this->proxy = new \Magento\Catalog\Api\ProductRepositoryInterface\Proxy(\Magento\Framework\App\ObjectManager::getInstance());
    }
}
