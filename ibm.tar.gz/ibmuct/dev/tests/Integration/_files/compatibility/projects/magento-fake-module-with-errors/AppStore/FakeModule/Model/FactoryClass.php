<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\FakeModule\Model;

use Magento\Catalog\Model\ResourceModel\Product\NonExisting;
use Magento\Catalog\Model\ResourceModel\Product\NonExistingFactory;

class FactoryClass
{
    /**
     * @var NonExisting
     */
    private $nonExistingClass;

    public function __construct()
    {
        $this->nonExistingClass = NonExistingFactory::create();
    }
}
