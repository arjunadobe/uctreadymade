<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\FakeModule\Model;

use Magento\CatalogSearch\Model\Indexer\Fulltext\Action\Full;
use Magento\CatalogSearch\Model\Indexer\IndexSwitcherInterface;
use Magento\CatalogSearch\Model\Indexer\Scope\UnknownStateException;
use Magento\CatalogSearch\Model\ResourceModel\EngineProvider;

/**
 * Extended with Adobe Commerce deprecated class
 * Implements with Adobe Commerce deprecated interface
 */
class FakeDeprecateClass extends UnknownStateException implements IndexSwitcherInterface
{
    private $_width;

    /**
     * Set image width property
     *
     * @param int $width
     * @return $this
     */
    public function setWidth($width)
    {
        $this->_width = $width;
        return $this;
    }

    /**
     * Get image width property
     *
     * @return int
     */
    public function getWidth()
    {
        return $this->_width;
    }

    /**
     * Call Adobe Commerce constant that is deprecated \Magento\CatalogSearch\Model\ResourceModel\EngineProvider
     * Call Adobe Commerce property that is deprecated from \Magento\CatalogSearch\Model\ResourceModel\EngineProvider
     * Call Adobe Commerce method that is deprecated from \Magento\CatalogSearch\Model\Indexer\Fulltext\Action\Full
     */
    public function addTables()
    {
        $configEnginePath = EngineProvider::CONFIG_ENGINE_PATH;
        $scopeConfig = EngineProvider::$scopeConfig;
        Full::reindexAll();

        $full = new Full();
        // Pass a string to a parameter expecting an int, omit an optional parameter
        $full->rebuildStoreIndex('aa');
        // Pass a string to a parameter expecting int[]
        $full->rebuildStoreIndex(25, 'bb');
        // Pass string[] to a parameter expecting int[]
        $full->rebuildStoreIndex(25, ['a', 'b']);
        // Right call
        $full->rebuildStoreIndex(25, [1, 2]);
    }
}
