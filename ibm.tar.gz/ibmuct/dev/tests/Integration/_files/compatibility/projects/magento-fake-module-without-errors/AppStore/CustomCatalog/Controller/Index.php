<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\CustomCatalog\Controller;

use Magento\Backend\App\Action;
use Magento\Tax\Api\Data\QuoteDetailsItemInterfaceFactory;

class Index extends Action
{
    /**
     * @var \Magento\Catalog\Helper\Product\Interceptor
     */
    private $interceptor;

    /**
     * @var \Magento\Catalog\Model\Product\Option\Logger
     */
    private $logger;

    /**
     * @var \Magento\Customer\Model\Customer\Repository
     */
    private $repository;

    /**
     * @var \Magento\Catalog\Model\Product\Option\SearchResults
     */
    private $searchResults;

    /**
     * @var \Magento\Catalog\Model\Product\Option\ProxyDeferred
     */
    private $proxyDeferred;

    /**
     * @var \Magento\Tax\Api\Data\QuoteDetailsItemExtensionFactory
     */
    private $extensionFactory;

    /**
     * @var \Magento\Tax\Api\Data\AppliedTaxInterfaceFactory
     */
    private $appliedTaxRateDataObjectFactory;

    /**
     * Index constructor.
     */
    public function __construct()
    {
        $this->interceptor = new \Magento\Catalog\Model\Product\Option\Interceptor();
        $this->logger = new \Magento\Catalog\Model\Product\Option\Logger();
        $this->repository = new \Magento\Customer\Model\Customer\Repository();
        $this->searchResults = new \Magento\Catalog\Model\Product\Option\SearchResults();
        $this->proxyDeferred = new \Magento\Catalog\Model\Product\Option\ProxyDeferred();
        $this->appliedTaxRateDataObjectFactory = new \Magento\Tax\Api\Data\AppliedTaxInterfaceFactory();
    }

    /**
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Tax\Api\Data\QuoteDetailsItemExtensionInterface $extensionAttribute */
        $extensionAttribute = $this->extensionFactory->create();
        $rateDataObject = $this->appliedTaxRateDataObjectFactory->create();
    }
}
