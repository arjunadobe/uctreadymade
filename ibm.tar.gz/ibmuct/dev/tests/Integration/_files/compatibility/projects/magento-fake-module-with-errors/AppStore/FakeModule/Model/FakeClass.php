<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\FakeModule\Model;

use Magento\Catalog\Model\Product\CatalogPriceFactory;
use Magento\Catalog\Model\Product\Gallery\ImagesConfigFactoryInterface;
use Magento\Catalog\Model\Product\Image;
use Magento\Catalog\Model\Product\PriceModifier;

/**
 * Extended with Adobe Commerce class that is not on Magento api
 * Implements with Adobe Commerce interface that is not on Magento api
 */
class FakeClass extends Image implements ImagesConfigFactoryInterface
{
    private $_width;

    /**
     * Set image width property
     *
     * @param int $width
     * @return $this
     */
    public function setWidth($width)
    {
        $this->_width = $width;
        return $this;
    }

    /**
     * Get image width property
     *
     * @return int
     */
    public function getWidth()
    {
        return $this->_width;
    }

    /**
     * Call Adobe Commerce constant that is not in the api \Magento\Catalog\Model\Product\Image
     * Call Adobe Commerce property that is not in the api \Magento\Catalog\Model\Product\PriceModifier
     * Call Adobe Commerce method that is not in the api \Magento\Catalog\Model\Product\CatalogPriceFactory
     */
    public function addTables()
    {
        $xmlPath = Image::XML_PATH_JPEG_QUALITY;

        /**
         * @var PriceModifier $priceModifier
         */

        $priceModifier->productRepository;

        $this->methodWithPriceModifier($priceModifier);

        /**
         * @var CatalogPriceFactory $catalogPriceFactory
         */

        $catalogPriceFactory->create('hello');

        $this->methodWithCatalogPriceFactory($catalogPriceFactory);
    }

    private function methodWithCatalogPriceFactory(CatalogPriceFactory $catalogPriceFactory)
    {
        $catalogPriceFactory->create('hello');
    }

    private function methodWithPriceModifier(PriceModifier $priceModifier)
    {
        $priceModifier->productRepository;
    }
}
