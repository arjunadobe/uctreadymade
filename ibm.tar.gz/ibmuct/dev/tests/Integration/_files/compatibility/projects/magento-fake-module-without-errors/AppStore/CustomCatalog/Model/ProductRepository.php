<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace AppStore\CustomCatalog\Model;

/** Implements with Adobe Commerce class that is on Adobe Commerce api and not deprecated **/
class ProductRepository implements \Magento\Catalog\Api\ProductRepositoryInterface
{
    public function getDetails()
    {
        return true;
    }
}
