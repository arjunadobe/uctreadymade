define([
	'jquery'
], function ($) {
	$.isFunction({});
});
