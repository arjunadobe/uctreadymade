define([
    'jquery'
], function ($) {
    $.trim('    hello, how are you?    ');
});
