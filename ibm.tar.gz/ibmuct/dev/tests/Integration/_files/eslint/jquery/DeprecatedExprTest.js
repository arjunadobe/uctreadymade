define([
	'jquery'
], function (jQuery) {
	jQuery.extend(jQuery.expr[':'], {});
});
