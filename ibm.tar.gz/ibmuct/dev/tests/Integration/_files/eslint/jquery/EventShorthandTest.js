define([
    'jquery'
], function ($) {
    $('#result').unload('ajax/test.html');
});
