define([
	'jquery'
], function ($) {
	$('div').find('p').andSelf().addClass('border');
});
