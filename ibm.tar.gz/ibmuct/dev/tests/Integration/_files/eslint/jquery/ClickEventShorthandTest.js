define([
    'jquery'
], function ($) {
    $('input').blur();
});
