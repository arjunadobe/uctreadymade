define([
    'jquery'
], function ($) {
    $('div').size();
});
