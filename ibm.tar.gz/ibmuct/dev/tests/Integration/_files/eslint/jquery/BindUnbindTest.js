define([
    'jquery'
], function ($) {
    $('.btn1').bind('click');
});
