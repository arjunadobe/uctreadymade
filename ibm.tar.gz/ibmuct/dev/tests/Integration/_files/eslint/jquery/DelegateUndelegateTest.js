define([
    'jquery'
], function ($) {
    $('table').delegate('td', 'click', function () {
        $(this).toggleClass('chosen');
    });
});
