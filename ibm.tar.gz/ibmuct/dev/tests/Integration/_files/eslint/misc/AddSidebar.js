define([
	'jquery',
	'tinyMCE'
], function ($, editor) {
	var name = 'my-sidebar', spec = '{tooltip: "My sidebar"}';

	editor.addSidebar(name, spec);
});
