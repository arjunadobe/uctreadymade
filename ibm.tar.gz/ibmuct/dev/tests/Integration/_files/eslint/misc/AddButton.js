define([
	'jquery',
	'tinyMCE'
], function ($, editor) {
	var identifier = 'toc', configuration = '{tooltip:"Table of Contents"}';

	editor.addButton(identifier, configuration);
});
