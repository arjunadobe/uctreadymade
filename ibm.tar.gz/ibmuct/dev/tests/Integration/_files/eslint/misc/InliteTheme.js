define([
	'jquery',
	'tinyMCE'
], function ($, editor) {
	editor.init({
		selector: 'div.tinymce',
		theme: 'inlite',
		inline: true
	});
});
