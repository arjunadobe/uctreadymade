define([
	'jquery',
	'tinyMCE'
], function ($, editor) {
	editor.init({
		selector: 'textarea',
		theme: 'silver',
		mobile: {
			theme: 'mobile',
			plugins: 'autosave lists autolink'
		}
	});
});
