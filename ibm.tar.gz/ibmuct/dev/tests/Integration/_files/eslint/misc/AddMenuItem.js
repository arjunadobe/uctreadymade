define([
	'jquery',
	'tinyMCE'
], function ($, editor) {
	var name = 'example', settings = '{text: "My Menu Item"}';

	editor.addMenuItem(name, settings);
});
