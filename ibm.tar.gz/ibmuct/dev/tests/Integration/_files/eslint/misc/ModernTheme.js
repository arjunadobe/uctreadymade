define([
	'jquery',
	'tinyMCE'
], function ($, editor) {
	editor.init({
		theme: 'modern',
		inline: true
	});
});
