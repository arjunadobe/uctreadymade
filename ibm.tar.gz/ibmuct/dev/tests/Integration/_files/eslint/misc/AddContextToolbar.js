define([
	'jquery',
	'tinyMCE'
], function ($, editor) {
	var items = 'tocupdate', predicate = 'function(t){return t&&e.dom.is(t,"."+l(e))&&e.getBody().contains(t)}';

	editor.addContextToolbar(predicate, items);
});
