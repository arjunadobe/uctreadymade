define([
	'jquery',
	'tinyMCE'
], function ($, editor) {
	editor.init({
		selector: 'textarea',  // change this value according to your HTML
		file_browser_callback: function (field_name, url, type, win) {
			win.document.getElementById(field_name).value = 'my browser value';
		}
	});
});
