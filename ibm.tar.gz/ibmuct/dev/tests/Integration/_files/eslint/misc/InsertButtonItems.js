define([
	'jquery',
	'tinyMCE'
], function ($, editor) {
	editor.init({
		toolbar: 'insert',
		insert_button_items: 'image link | insert table'
	});
});
