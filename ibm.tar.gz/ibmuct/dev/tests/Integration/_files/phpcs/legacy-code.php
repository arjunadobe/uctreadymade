<?php

// Generic.PHP.Syntax.PHPSyntax
function f(&$v){$v = true;}
f(&$v);

// Magento2.Legacy.MageEntity.FoundLegacyEntity
Mage::getModel('Model');

// PHPCompatibility
var_dump(filter_var($var, FILTER_SANITIZE_MAGIC_QUOTES));

// Magento2.PHPCompatibility
sem_get($key, $max_acquire, $perm, 0);

class ClassWithIssues
{
    final private function getter()
    {
        return $this;
    }
}

copy();

// Test for PHPCompatibility.FunctionUse.RemovedFunctions.<method>Deprecated
utf8_decode($var);

// Test for PHPCompatibility.FunctionUse.RemovedFunctions.<method>DeprecatedRemoved
each($var);
