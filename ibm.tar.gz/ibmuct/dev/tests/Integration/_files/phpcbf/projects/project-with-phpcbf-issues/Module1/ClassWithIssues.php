<?php

namespace phpcbf;

class ClassWithIssues
{

    final private function getter()
    {
        return $this;
    }

    public function run($optional = 1, $required)
    {
        $f = finfo_open();
        is_resource($f);
    }
}
