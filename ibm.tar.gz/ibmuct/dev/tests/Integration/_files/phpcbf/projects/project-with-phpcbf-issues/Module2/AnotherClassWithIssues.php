<?php

namespace phpcbf;

class AnotherClassWithIssues
{

    public function __set_state($state)
    {

    }
}
