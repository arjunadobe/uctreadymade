<?php

namespace rector;

class ClassWithoutPhpCbfIssues
{

    private function getter()
    {
        return $this;
    }
}
