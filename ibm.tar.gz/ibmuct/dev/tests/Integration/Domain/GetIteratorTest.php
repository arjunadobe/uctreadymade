<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace Sut\Tests\Integration\Domain;

use PHPUnit\Framework\TestCase;
use Sut\Domain\Etalon\GetIterator;
use Sut\Infrastructure\Etalon\MD5File;

class GetIteratorTest extends TestCase
{
    /**
     * @param string $path
     * @param string[] $files
     * @param string[] $excluded
     * @param bool $addEmptyDirectory
     * @dataProvider pathProvider
     */
    public function testExecute(string $path, array $files, array $excluded, bool $addEmptyDirectory = true): void
    {
        $emptyDirectory = rtrim($path, '/') . '/empty';
        if ($addEmptyDirectory && !file_exists($emptyDirectory)) {
            mkdir($emptyDirectory);
        }

        $iterable = (new GetIterator(new MD5File(), $excluded))->execute($path);
        $actualFiles = [];
        foreach ($iterable as $currentFile => $hash) {
            $actualFiles[] = $currentFile;
        }

        $this->assertEqualsCanonicalizing(
            $files,
            $actualFiles,
            'Etalon iterator returns an incorrect set of files'
        );

        if ($addEmptyDirectory && file_exists($emptyDirectory)) {
            rmdir($emptyDirectory);
        }
    }

    /**
     * @return array[]
     */
    public function pathProvider(): array
    {
        return [
            [
                'path' => __DIR__ . '/../_files/etalon',
                'files' => [
                    'a.txt',
                    'folder/c.txt',
                    'soft.txt',
                    '.hidden',
                    'empty',
                    'folder',
                ],
                ['b.txt'],
                true
            ],
            [
                'path' => __DIR__ . '/../_files/etalon/',
                'files' => [
                    'b.txt',
                    'folder/c.txt',
                    'soft.txt',
                    '.hidden',
                    'empty',
                    'folder',
                ],
                ['a.txt'],
                true
            ],
            [
                'path' => __DIR__ . '/../_files/etalon/',
                'files' => [],
                [
                    'a.txt',
                    'b.txt',
                    'folder/c.txt',
                    'soft.txt',
                    '.hidden',
                    'folder'
                ],
                false
            ]
        ];
    }
}
