<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace Sut\Tests\Integration\Domain;

use InvalidArgumentException;
use PHPUnit\Framework\TestCase;
use Sut\Domain\Etalon\GetIterator;
use Sut\Domain\Etalon\GetModifiedFiles;
use Sut\Domain\Etalon\GetUpdatedPackages;
use Sut\Domain\Issue\DTO\Issue;
use Sut\Domain\Issue\DTO\IssueLevel;
use Sut\Domain\Issue\IssueFactory;
use Sut\Infrastructure\Etalon\MD5File;

class GetModifiedFilesTest extends TestCase
{
    public function testExecute(): void
    {
        $dir = __DIR__ . '/../_files/modified-files';
        $expectedIssues = [
            new Issue(
                IssueLevel::CRITICAL,
                "Core file 'file2.txt' is modified",
                2002,
                0,
                '',
                '',
                'core'
            ),
            new Issue(
                IssueLevel::CRITICAL,
                "Core file 'file3.txt' was not found",
                2001,
                0,
                '',
                '',
                'core'
            ),
        ];
        $issuesConfig = [
            'issues' =>
                [
                    2002 =>
                        [
                            'message' => "Core file '%s' is modified",
                            'level' => 1
                        ],
                    2001 =>
                        [
                            'message' => "Core file '%s' was not found",
                            'level' => 1
                        ]
                ]
        ];
        $expectedTotalCheckedFiles = 3;

        $modifiedFiles = $this->getService($issuesConfig)->execute($dir . '/project', $dir . '/etalon');

        $this->assertEqualsCanonicalizing(
            $expectedIssues,
            $modifiedFiles->getIssues(),
            'Modified files finder returns an incorrect set of files'
        );

        $this->assertEquals($expectedTotalCheckedFiles, $modifiedFiles->getTotalCheckedFiles());
    }

    public function testExecuteIssueNotFound(): void
    {
        $dir = __DIR__ . '/../_files/modified-files';
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Issue code 2002 is not defined in the configuration');
        $this->getService([])->execute($dir . '/project', $dir . '/etalon');
    }

    private function getService(array $issueConfig): GetModifiedFiles
    {
        $hasher = new MD5File();
        $issueFactory = new IssueFactory($issueConfig);
        return new GetModifiedFiles(
            $hasher,
            new GetIterator($hasher),
            new GetUpdatedPackages($issueFactory),
            $issueFactory
        );
    }
}
