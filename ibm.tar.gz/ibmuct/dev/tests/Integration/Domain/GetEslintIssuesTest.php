<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace Sut\Tests\Integration\Domain;

use Sut\Domain\Eslint\GetEslintIssues;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

class GetEslintIssuesTest extends KernelTestCase
{

    protected function setUp(): void
    {
        parent::setUp();
        self::bootKernel();
    }

    public function testGetEslintIssues(): void
    {
        /** @var GetEslintIssues $getEslintIssues */
        $getEslintIssues = self::$container->get('sut_eslint_get_issues');
        $dir = self::$container->getParameter('integration_tests_files_path') . 'eslint';
        $issues = $getEslintIssues->execute($dir);

        $this->assertCount(18, $issues);

        $expectedIssues = [
            [
                "type" => "jquery-no-andSelf",
                "code" => 6001,
                "line" => 4,
                "message" => "jQuery.andSelf() removed, use jQuery.addBack()",
                "fileName" => "jquery/AndSelfTest.js"
            ],
            [
                "type" => "jquery-no-bind-unbind",
                "code" => 6002,
                "line" => 4,
                "message" => "jQuery $.bind and $.unbind are deprecated, use $.on and $.off instead",
                "fileName" => "jquery/BindUnbindTest.js"
            ],
            [
                "type" => "jquery-no-input-event-shorthand",
                "code" => 6003,
                "line" => 4,
                "message" => 'Instead of .blur(fn) use .on("blur", fn). Instead of .blur() use .trigger("blur")',
                "fileName" => "jquery/ClickEventShorthandTest.js"
            ],
            [
                "type" => "jquery-no-delegate-undelegate",
                "code" => 6004,
                "line" => 4,
                "message" => "jQuery $.delegate and $.undelegate are deprecated, use $.on and $.off instead",
                "fileName" => "jquery/DelegateUndelegateTest.js"
            ],
            [
                "type" => "jquery-no-event-shorthand",
                "code" => 6005,
                "line" => 4,
                "message" => 'jQuery.unload() was removed, use .on("unload", fn) instead.',
                "fileName" => "jquery/EventShorthandTest.js"
            ],
            [
                "type" => "jquery-no-size",
                "code" => 6006,
                "line" => 4,
                "message" => "jQuery.size() removed, use jQuery.length",
                "fileName" => "jquery/SizeTest.js"
            ],
            [
                "type" => "jquery-no-trim",
                "code" => 6007,
                "line" => 4,
                "message" => "jQuery.trim is deprecated; use String.prototype.trim",
                "fileName" => "jquery/TrimTest.js"
            ],
            [
                "type" => "no-restricted-syntax",
                "code" => 6008,
                "line" => 7,
                "message" => "addButton is removed. Update code to be compatible with tinymce5",
                "fileName" => "misc/AddButton.js"
            ],
            [
                "type" => "no-restricted-syntax",
                "code" => 6008,
                "line" => 7,
                "message" => "addContextToolbar is removed. Update code to be compatible with tinymce5",
                "fileName" => "misc/AddContextToolbar.js"
            ],
            [
                "type" => "no-restricted-syntax",
                "code" => 6008,
                "line" => 7,
                "message" => "addMenuItem is removed. Update code to be compatible with tinymce5",
                "fileName" => "misc/AddMenuItem.js"
            ],
            [
                "type" => "no-restricted-syntax",
                "code" => 6008,
                "line" => 7,
                "message" => "addSidebar is removed. Update code to be compatible with tinymce5",
                "fileName" => "misc/AddSidebar.js"
            ],
            [
                "type" => "no-restricted-syntax",
                "code" => 6008,
                "line" => 7,
                "message" => "file_browser_callback is removed. Update code to be compatible with tinymce5",
                "fileName" => "misc/FileBrowserCallback.js"
            ],
            [
                "type" => "no-restricted-syntax",
                "code" => 6008,
                "line" => 7,
                "message" => "insert_button_items is removed. Update code to be compatible with tinymce5",
                "fileName" => "misc/InsertButtonItems.js"
            ],
            [
                "type" => "no-restricted-syntax",
                "code" => 6008,
                "line" => 7,
                "message" => "'inlite' theme is removed. Update code to be compatible with tinymce5",
                "fileName" => "misc/InliteTheme.js"
            ],
            [
                "type" => "no-restricted-syntax",
                "code" => 6008,
                "line" => 9,
                "message" => "'mobile' theme is removed. Update code to be compatible with tinymce5",
                "fileName" => "misc/MobileTheme.js"
            ],
            [
                "type" => "no-restricted-syntax",
                "code" => 6008,
                "line" => 6,
                "message" => "'modern' theme is removed. Update code to be compatible with tinymce5",
                "fileName" => "misc/ModernTheme.js"
            ],
            [
                "type" => "jquery-no-misc-deprecated-functions",
                "code" => 6009,
                "line" => 4,
                "message" => "jQuery.isFunction() is deprecated. " .
                    "In most cases, it can be replaced by [typeof x === \"function\"]",
                "fileName" => "jquery/MiscDeprecatedFunctionsTest.js"
            ],
            [
                "type" => "jquery-no-deprecated-expr",
                "code" => 6010,
                "line" => 4,
                "message" => "jQuery.expr[\":\"] is deprecated; Use jQuery.expr.pseudos instead",
                "fileName" => "jquery/DeprecatedExprTest.js"
            ]
        ];

        foreach ($expectedIssues as $expectedIssue) {
            $found = false;
            foreach ($issues as $issue) {
                if ($issue->getMessage() === $expectedIssue['message'] &&
                    $issue->getIssueType() === $expectedIssue['type'] &&
                    $issue->getCode() === $expectedIssue['code'] &&
                    $issue->getLineNumber() === $expectedIssue['line'] &&
                    strpos($issue->getFileName(), $expectedIssue['fileName']) !== false
                ) {
                        $found = true;
                }
            }
            if (!$found) {
                $this->assertTrue($found, sprintf("Expected issue %s not found", json_encode($expectedIssue)));
            }
        }
    }
}
