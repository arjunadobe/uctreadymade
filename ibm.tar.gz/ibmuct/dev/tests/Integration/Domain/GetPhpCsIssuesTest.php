<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace Sut\Tests\Integration\Domain;

use Sut\Domain\Issue\DTO\Issue;
use Sut\Domain\PhpCs\GetPhpCsIssues;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

class GetPhpCsIssuesTest extends KernelTestCase
{

    protected function setUp(): void
    {
        parent::setUp();
        self::bootKernel();
    }

    /**
     * @param string $directory
     * @param array $expectedIssues
     * @dataProvider directoryProvider
     */
    public function testGetPhpCsIssues(string $directory, array $expectedIssues): void
    {
        $testDirectory = self::$container->getParameter('integration_tests_files_path');
        /** @var GetPhpCsIssues $getPhpCsIssues */
        $getPhpCsIssues = self::$container->get('sut_phpcs_get_issues');
        $issues = $getPhpCsIssues->execute($testDirectory . $directory);

        $this->assertEquals($expectedIssues, $this->toAssocArray($issues, $testDirectory));
    }

    /**
     * @param array $issues
     * @param string $testDirectory
     * @return array
     */
    private function toAssocArray(array $issues, string $testDirectory): array
    {
        usort(
            $issues,
            function (Issue $first, Issue $second) {
                return $first->getLineNumber() <=> $second->getLineNumber();
            }
        );

        $array = [];

        foreach ($issues as $issue) {
            $array[] = [
                'type' => $issue->getIssueType(),
                'code' => $issue->getCode(),
                'line' => $issue->getLineNumber(),
                'message' => $issue->getMessage(),
                'fileName' => substr($issue->getFileName(), strlen($testDirectory))
            ];
        }

        return $array;
    }

    /**
     * @return array[]
     */
    public function directoryProvider(): array
    {
        return [
            [
                'phpcs',
                [
                    [
                        'type' => 'Magento2.Templates.ThisInTemplate.FoundThis',
                        'code' => 5082,
                        'line' => 2,
                        'message' => 'The use of $this in templates is deprecated. Use $block instead.',
                        'fileName' => 'phpcs/view/frontend/web/index.phtml'
                    ],
                    [
                        'type' => 'Generic.PHP.Syntax.PHPSyntax',
                        'code' => 5005,
                        'line' => 5,
                        'message' => 'PHP syntax error: syntax error, unexpected token "&"',
                        'fileName' => 'phpcs/legacy-code.php'
                    ],
                    [
                        'type' => 'Magento2.Legacy.MageEntity.FoundLegacyEntity',
                        'code' => 5072,
                        'line' => 8,
                        'message' => 'Possible Magento 2 design violation. ' .
                            'Detected typical Magento 1.x construction "Mage::".',
                        'fileName' => "phpcs/legacy-code.php"
                    ],
                    [
                        'type' => 'Magento2.Functions.DiscouragedFunction.Discouraged',
                        'code' => 5007,
                        'line' => 11,
                        'message' => 'The use of function var_dump() is discouraged',
                        'fileName' => 'phpcs/legacy-code.php'
                    ],
                    [
                        'type' => 'PHPCompatibility.Constants.RemovedConstants' .
                            '.filter_sanitize_magic_quotesDeprecatedRemoved',
                        'code' => 5087,
                        'line' => 11,
                        'message' => 'The constant "FILTER_SANITIZE_MAGIC_QUOTES" is deprecated since PHP 7.4' .
                            ' and removed since PHP 8.0; Use FILTER_SANITIZE_ADD_SLASHES instead',
                        'fileName' => 'phpcs/legacy-code.php'
                    ],
                    [
                        'type' => 'PHPCompatibility.ParameterValues.ChangedIntToBoolParamType'
                            . '.sem_get_auto_releaseNumericFound',
                        'code' => 5087,
                        'line' => 14,
                        'message' => 'The $auto_release parameter of sem_get() expects a boolean value instead of '
                            . 'an integer since PHP 8.0. Found: 0',
                        'fileName' => "phpcs/legacy-code.php"
                    ],
                    [
                        "type" => 'PHPCompatibility.FunctionDeclarations.ForbiddenFinalPrivateMethods.Found',
                        "code" => 5087,
                        "line" => 18,
                        "message" => "Private methods should not be declared as final since PHP 8.0",
                        "fileName" => "phpcs/legacy-code.php"
                    ],
                    [
                        'type' => 'Magento2.Functions.DiscouragedFunction.DiscouragedWithAlternative',
                        'code' => 5007,
                        'line' => 24,
                        'message' => 'The use of function copy() is discouraged; ' .
                            'use Magento\Framework\Filesystem\DriverInterface::copy() instead',
                        'fileName' => 'phpcs/legacy-code.php'
                    ],
                    [
                        'type' => 'PHPCompatibility.FunctionUse.RemovedFunctions.utf8_decodeDeprecated',
                        'code' => 5087,
                        'line' => 27,
                        'message' => 'Function utf8_decode() is deprecated since PHP 8.2;' .
                            ' Use mb_convert_encoding(), UConverter::transcode() or iconv instead',
                        'fileName' => 'phpcs/legacy-code.php'
                    ],
                    [
                        'type' => 'PHPCompatibility.FunctionUse.RemovedFunctions.eachDeprecatedRemoved',
                        'code' => 5086,
                        'line' => 30,
                        'message' => 'Function each() is deprecated since PHP 7.2 and removed since PHP 8.0;' .
                            ' Use a foreach loop or ArrayIterator instead',
                        'fileName' => 'phpcs/legacy-code.php'
                    ]
                ]
            ]
        ];
    }
}
