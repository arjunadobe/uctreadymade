<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace Sut\Tests\Integration\Domain;

use InvalidArgumentException;
use PHPUnit\Framework\TestCase;
use RuntimeException;
use Sut\Domain\Magento\GetProjectInfo;

class GetProjectInfoTest extends TestCase
{
    /**
     * @var GetProjectInfo
     */
    private $getProjectInfo;

    public function setUp(): void
    {
        $this->getProjectInfo = new GetProjectInfo();
    }

    /**
     * @param string $path
     * @param string|null $version
     * @param string|null $edition
     * @throws \JsonException
     * @dataProvider projectsProvider
     */
    public function testExecute(string $path, ?string $version, ?string $edition): void
    {
        $info = $this->getProjectInfo->execute($path);

        $this->assertEquals($version, $info->getVersion());
        $this->assertEquals($edition, $info->getEdition());
    }

    /**
     * @return array[]
     */
    public function projectsProvider(): array
    {
        return [
            [__DIR__ . '/../_files/magentoInstallations/magento2.4.0', '2.4.0', 'EE']
        ];
    }

    /**
     * @param string $path
     * @param string $exception
     * @throws \JsonException
     * @dataProvider exceptionsProvider
     */
    public function testException(string $path, string $exception)
    {
        $this->expectException($exception);
        $this->getProjectInfo->execute($path);
    }

    /**
     * @return \string[][]
     */
    public function exceptionsProvider(): array
    {
        return [
            [__DIR__ . '/../_files/magentoInstallations/directory_does_not_exist', InvalidArgumentException::class],
            [__DIR__ . '/../_files/compatibility/projects/magento2.4.0-no-version', RuntimeException::class]
        ];
    }
}
