<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace Sut\Tests\Integration\Infrastructure\Entrypoint\Command;

use Sut\Domain\Compatibility\GetMemoryPeakUsage;
use Sut\Domain\Compatibility\Index;
use Sut\Infrastructure\Entrypoint\Command\CheckCommand;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Tester\CommandTester;

class CheckCommandExceptionTest extends KernelTestCase
{
    private const MEMORY_PEAK_USAGE = 117.73756885528564;

    /**
     * @var CommandTester
     */
    private $commandTester;

    protected function setUp(): void
    {
        self::bootKernel();
        $indexedVersionsMock = $this->createMock(Index::class);
        $indexedVersionsMock->method('getAvailableVersions')
            ->willReturn([]);
        $command = new CheckCommand(
            self::$container->get('sut_magento_service'),
            self::$container->get('sut_compatibility_get_issues'),
            self::$container->get('sut_compatibility_output'),
            self::$container->get('sut_compatibility_request_factory'),
            $indexedVersionsMock,
            self::$container->getParameter('documentationLink')
        );
        $this->commandTester = new CommandTester($command);
    }

    /**
     * @param array $input
     * @param string $message
     * @dataProvider executeProvider
     */
    public function testExecuteException(
        array $input,
        string $message
    ): void {
        if (isset($input['dir'])) {
            $input['dir'] = self::$container->getParameter('integration_tests_files_path')
                . 'compatibility/projects/' . $input['dir'];
        }

        $result = $this->commandTester->execute($input);

        $this->assertEquals(Command::FAILURE, $result, 'Command should return failure (1) exit code.');
        $this->assertStringContainsString($message, $this->commandTester->getDisplay());
        $this->assertStringNotContainsString('Analysing 1 modules...', $this->commandTester->getDisplay());
    }

    /**
     * @return array[]
     */
    public function executeProvider(): array
    {
        return [
            'incorrect_coming_version' => [
                [
                    'dir' => 'magento-fake-module-without-errors',
                    '--coming-version' => '9.0.0'
                ],
                'Upgrade check for Adobe Commerce version 9.0.0 is not available.'
            ],
            'incorrect_coming_version_with_ignore_current_version' => [
                [
                    'dir' => 'magento-fake-module-without-errors',
                    '--ignore-current-version-compatibility-issues' => true,
                    '--coming-version' => '9.0.0'
                ],
                'Upgrade check for Adobe Commerce version 9.0.0 is not available.'
            ],
            'incorrect_current_version_with_ignore_current_version' => [
                [
                    'dir' => 'magento-fake-module-without-errors',
                    '--ignore-current-version-compatibility-issues' => true,
                    '--coming-version' => '2.4.0',
                    '--current-version' => '9.0.0'
                ],
                'Upgrade check for Adobe Commerce version 9.0.0 is not available.'
            ],
            'missing_version' => [
                [
                    'dir' => 'magento2.4.0-no-version'
                ],
                'Please rerun the command specifying the --current-version option'
            ],
            'invalid_min_issue_level' => [
                [
                    'dir' => 'magento-fake-module-without-errors',
                    '--min-issue-level' => 'debug'
                ],
                '"debug" is not a valid issue level.'
            ],
            'no_coming_version_empty_indexed_versions_return' => [
                [
                    'dir' => 'magento-fake-module-without-errors',
                ],
                'Please rerun the command specifying the --coming-version option'
            ],
            'invalid_project_path' => [
                [
                    'dir' => 'non-existing-path',
                    '--current-version' => '2.4.2',
                    '--coming-version' => '2.4.4',
                ],
                'Requested project path does not exist or is not a directory'
            ]
        ];
    }
}
