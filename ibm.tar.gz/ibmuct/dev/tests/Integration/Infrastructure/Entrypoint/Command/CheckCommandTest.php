<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace Sut\Tests\Integration\Infrastructure\Entrypoint\Command;

use DateInterval;
use DateTime;
use org\bovigo\vfs\vfsStream;
use org\bovigo\vfs\vfsStreamDirectory;
use PHPUnit\Framework\MockObject\MockObject;
use Sut\Domain\Compatibility\GetMemoryPeakUsage;
use Sut\Domain\Compatibility\Index;
use Sut\Domain\Time\TimerInterface;
use Sut\Domain\Tracking\Track\UpdateCheckData;
use Sut\Domain\Tracking\Tracker;
use Sut\Infrastructure\Entrypoint\Command\CheckCommand;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Tester\CommandTester;

class CheckCommandTest extends KernelTestCase
{
    private const EXPECTED_EXECUTION_TIME = 20;
    private const MEMORY_PEAK_USAGE = 117.73756885528564;

    /**
     * @var vfsStreamDirectory
     */
    private $fileSystemMock;

    /**
     * @var CommandTester
     */
    private $commandTester;

    /**
     * @var MockObject|Tracker
     */
    private $trackerMock;

    protected function setUp(): void
    {
        self::bootKernel();

        $directory = [
            'output' => []
        ];
        $this->fileSystemMock = vfsStream::setup('root', 444, $directory);
        $this->trackerMock = $this->createMock(Tracker::class);
        $timerMock = $this->createMock(TimerInterface::class);
        $timerMock->method('time')
            ->willReturn(time());
        $indexedVersionsMock = $this->createMock(Index::class);
        $indexedVersionsMock->method('getAvailableVersions')
            ->willReturn(['2.3.7', '2.4.2']);
        $getMemoryPeakUsageMock = $this->createMock(GetMemoryPeakUsage::class);
        $getMemoryPeakUsageMock->method('execute')
            ->willReturn(self::MEMORY_PEAK_USAGE);
        self::$container->set(Tracker::class, $this->trackerMock);
        self::$container->set(TimerInterface::class, $timerMock);
        self::$container->set(GetMemoryPeakUsage::class, $getMemoryPeakUsageMock);

        $command = new CheckCommand(
            self::$container->get('sut_magento_service'),
            self::$container->get('sut_compatibility_get_issues'),
            self::$container->get('sut_compatibility_output'),
            self::$container->get('sut_compatibility_request_factory'),
            $indexedVersionsMock,
            self::$container->getParameter('documentationLink')
        );

        $this->commandTester = new CommandTester($command);
    }

    /**
     * @param array $input
     * @param string $expectedOutput
     * @param UpdateCheckData $expectedTracking
     * @dataProvider executeProvider
     */
    public function testExecute(
        array $input,
        string $expectedOutput,
        UpdateCheckData $expectedTracking
    ): void {
        $this->trackerMock->expects($this->once())
            ->method('sendData')
            ->willReturnCallback(
                function (UpdateCheckData $data) use ($expectedTracking) {
                    $this->assertEquals(
                        $expectedTracking,
                        $data,
                        sprintf(
                            'Received tracking data is %s but expected %s',
                            $data->serialize(),
                            $expectedTracking->serialize()
                        )
                    );
                }
            );

        if (isset($input['dir'])) {
            $input['dir'] = self::$container->getParameter('integration_tests_files_path')
                . 'compatibility/projects/' . $input['dir'];
        }
        if (isset($input['--json-output-path'])) {
            $input['--json-output-path'] = $this->fileSystemMock->url() . $input['--json-output-path'];
        }
        if (isset($input['--html-output-path'])) {
            $input['--html-output-path'] = $this->fileSystemMock->url() . $input['--html-output-path'];
        }

        $start = new DateTime();
        $result = $this->commandTester->execute($input);
        $end = new DateTime();

        $this->assertEquals(
            Command::SUCCESS,
            $result,
            sprintf(
                "Command returned not success (0) exit code.\nDisplay: %s",
                $this->commandTester->getDisplay(),
            )
        );
        $this->assertOutput($expectedOutput, $input['dir']);

        $durationInSeconds = $this->intervalToSeconds($end->diff($start));

        $this->assertLessThanOrEqual(
            self::EXPECTED_EXECUTION_TIME,
            $durationInSeconds,
            sprintf(
                'Upgrade check execution time was %.2f that is greater than expected %.2f',
                $durationInSeconds,
                self::EXPECTED_EXECUTION_TIME
            )
        );
    }

    /**
     * @return array[]
     */
    public function executeProvider(): array
    {
        $jsonOutput = '/output/result.json';
        $htmlOutput = '/output/result.html';
        return [
            'no_issues' => [
                [
                    'dir' => 'magento-fake-module-without-errors',
                    '--coming-version' => '2.4.2',
                    '--json-output-path' => $jsonOutput,
                    '--html-output-path' => $htmlOutput,
                    '--context' => 'phpstorm'
                ],
                'check_expected_output_empty',
                new UpdateCheckData(
                    0,
                    '2.4.0',
                    '2.4.2',
                    self::MEMORY_PEAK_USAGE,
                    0,
                    0,
                    0,
                    true,
                    'phpstorm'
                )
            ],
            'issue_level_warning' => [
                [
                    'dir' => 'magento-fake-module-with-errors',
                    '--coming-version' => '2.4.2',
                    '--json-output-path' => $jsonOutput,
                    '--html-output-path' => $htmlOutput,
                    '--ignore-current-version-compatibility-issues' => true,
                    '--min-issue-level' => 'warning'
                ],
                'check_expected_output-ignore-current-version',
                new UpdateCheckData(
                    0,
                    '2.3.0',
                    '2.4.2',
                    self::MEMORY_PEAK_USAGE,
                    1,
                    1,
                    0,
                    true
                )
            ],
            'issue_level_error' => [
                [
                    'dir' => 'magento-fake-module-with-errors',
                    '--coming-version' => '2.4.2',
                    '--json-output-path' => $jsonOutput,
                    '--html-output-path' => $htmlOutput,
                    '--ignore-current-version-compatibility-issues' => true,
                    '--min-issue-level' => 'error'
                ],
                'check_expected_output-ignore-current-version-level-error',
                new UpdateCheckData(
                    0,
                    '2.3.0',
                    '2.4.2',
                    self::MEMORY_PEAK_USAGE,
                    1,
                    1,
                    0
                )
            ],
            'issue_level_critical' => [
                [
                    'dir' => 'magento-fake-module-with-errors',
                    '--coming-version' => '2.4.2',
                    '--json-output-path' => $jsonOutput,
                    '--html-output-path' => $htmlOutput,
                    '--ignore-current-version-compatibility-issues' => true,
                    '--min-issue-level' => 'critical'
                ],
                'check_expected_output-ignore-current-version-level-critical',
                new UpdateCheckData(
                    0,
                    '2.3.0',
                    '2.4.2',
                    self::MEMORY_PEAK_USAGE,
                    1,
                    1,
                    0
                )
            ],
            'no_coming_version_latest_release_version_indexed' => [
                [
                    'dir' => 'magento-fake-module-without-errors',
                    '--json-output-path' => $jsonOutput,
                    '--html-output-path' => $htmlOutput
                ],
                'check_expected_output_no_coming_version',
                new UpdateCheckData(
                    0,
                    '2.4.0',
                    '2.4.2',
                    self::MEMORY_PEAK_USAGE,
                    0,
                    0,
                    0,
                    true,
                )
            ],
            'no_version_but_current_version_specified' => [
                [
                    'dir' => 'magento2.4.0-no-version',
                    '--coming-version' => '2.4.2',
                    '--current-version' => '2.4.0',
                    '--json-output-path' => $jsonOutput,
                    '--html-output-path' => $htmlOutput,
                ],
                'check_expected_output_empty_no_version',
                new UpdateCheckData(
                    0,
                    '2.4.0',
                    '2.4.2',
                    self::MEMORY_PEAK_USAGE,
                    0,
                    0,
                    0,
                    true,
                )
            ],
            'method-signature-validation' => [
                [
                    'dir' => 'method-signature-validation',
                    '--json-output-path' => $jsonOutput,
                    '--html-output-path' => $htmlOutput
                ],
                'method_signature_validation',
                new UpdateCheckData(
                    0,
                    '2.4.0',
                    '2.4.2',
                    self::MEMORY_PEAK_USAGE,
                    0,
                    6,
                    0
                )
            ],
            'di-xml' => [
                [
                    'dir' => 'project-di-xml',
                    '--json-output-path' => $jsonOutput,
                    '--html-output-path' => $htmlOutput
                ],
                'project-di-xml',
                new UpdateCheckData(
                    0,
                    '2.3.0',
                    '2.4.2',
                    self::MEMORY_PEAK_USAGE,
                    2,
                    0,
                    1
                )
            ],
            'db-schema' => [
                [
                    'dir' => 'project-db-schema',
                    '--json-output-path' => $jsonOutput,
                    '--html-output-path' => $htmlOutput,
                    '--coming-version' => '2.4.5',
                ],
                'project-db-schema',
                new UpdateCheckData(
                    0,
                    '2.3.0',
                    '2.4.5',
                    self::MEMORY_PEAK_USAGE,
                    8,
                    0,
                    2
                )
            ],
        ];
    }

    /**
     * @param string $fileName
     * @param string $projectDirectory
     */
    private function assertOutput(string $fileName, string $projectDirectory): void
    {
        $this->assertEquals(
            $this->normalizeCliOutput(
                file_get_contents(
                    sprintf(
                        '%s/compatibility/output/cli/%s.txt',
                        self::$container->getParameter('integration_tests_files_path'),
                        $fileName
                    )
                ),
                $projectDirectory
            ),
            $this->normalizeCliOutput($this->commandTester->getDisplay(), $projectDirectory)
        );

        $this->assertStringEqualsFile(
            sprintf(
                "%s/compatibility/output/json/%s.json",
                self::$container->getParameter('integration_tests_files_path'),
                $fileName
            ),
            $this->normalizeFileOutput(
                file_get_contents($this->fileSystemMock->url() . '/output/result.json'),
                $projectDirectory
            )
        );

        $this->assertStringEqualsFile(
            sprintf(
                "%s/compatibility/output/html/%s.html",
                self::$container->getParameter('integration_tests_files_path'),
                $fileName
            ),
            $this->normalizeHtmlOutput(
                file_get_contents($this->fileSystemMock->url() . '/output/result.html')
            )
        );
    }

    /**
     * @param string $content
     * @param string $projectDirectory
     * @return string
     */
    private function normalizeCliOutput(string $content, string $projectDirectory): string
    {
        return preg_replace(
            '/ +\n/',
            "\n",
            str_replace([$projectDirectory, '-'], '', $content)
        );
    }

    /**
     * @param string $content
     * @param string $projectDirectory
     * @return string
     */
    private function normalizeFileOutput(string $content, string $projectDirectory): string
    {
        return str_replace(
            str_replace('/', '\/', $projectDirectory),
            '',
            $content
        ) . "\n";
    }

    /**
     * @param string $content
     * @return string
     */
    private function normalizeHtmlOutput(string $content): string
    {
        return preg_replace(
            '/\d{1,2} [a-z]{3} \d{4} \d{2}:\d{2}/i',
            '',
            str_replace(self::$container->get('kernel')->getProjectDir(), '', $content)
        );
    }

    /**
     * @param DateInterval $interval
     * @return float
     */
    private function intervalToSeconds(DateInterval $interval): float
    {
        return round(
            $interval->days * 86400 + $interval->h * 3600 + $interval->i * 60 + $interval->s + $interval->f,
            2
        );
    }
}
