<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace Sut\Tests\Integration\Infrastructure\Entrypoint\Command;

use DateTime;
use org\bovigo\vfs\vfsStream;
use org\bovigo\vfs\vfsStreamDirectory;
use PHPUnit\Framework\MockObject\MockObject;
use Sut\Domain\Cmd\CommandExecution;
use Sut\Domain\Compatibility\GetMemoryPeakUsage;
use Sut\Domain\Statistics\Statistics;
use Sut\Domain\Tracking\Track\CoreCodeChangesData;
use Sut\Domain\Tracking\Tracker;
use Sut\Infrastructure\Cmd\CmdService;
use Sut\Infrastructure\Entrypoint\Command\CoreCodeChangesCommand;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\Console\Helper\HelperSet;
use Symfony\Component\Console\Helper\QuestionHelper;
use Symfony\Component\Console\Tester\CommandTester;

class CoreCodeChangesCommandTest extends KernelTestCase
{
    private const EXPECTED_EXECUTION_TIME = 0.5;
    private const MEMORY_PEAK_USAGE = 117.73756885528564;

    /**
     * @var CoreCodeChangesCommand
     */
    private $command;

    /**
     * @var MockObject
     */
    private $trackerMock;

    /**
     * @var vfsStreamDirectory
     */
    private $fileSystemMock;

    /**
     * @var string
     */
    private $outputPath;

    /**
     * @var MockObject|CmdService
     */
    private $cmdServiceMock;

    protected function setUp(): void
    {
        self::bootKernel();

        $this->trackerMock = $this->createMock(Tracker::class);
        $this->cmdServiceMock = $this->createMock(CmdService::class);
        $getMemoryPeakUsageMock = $this->createMock(GetMemoryPeakUsage::class);
        $getMemoryPeakUsageMock->method('execute')
            ->willReturn(self::MEMORY_PEAK_USAGE);
        $this->fileSystemMock = vfsStream::setup(
            'root',
            444,
            [
                'output' => []
            ]
        );
        $this->outputPath = $this->fileSystemMock->url() . "/output/%s-result.json";

        $this->command = new CoreCodeChangesCommand(
            self::$container->get('sut_output_format_type_core_modifications_console'),
            self::$container->get('sut_output_format_type_core_modifications_export'),
            self::$container->get('sut_get_modified_files'),
            self::$container->get('sut_magento_service'),
            $this->trackerMock,
            self::$container->get('sut_magento_filesystem'),
            $this->cmdServiceMock,
            $this->outputPath,
            self::$container->getParameter('errorCodesDocumentation'),
            self::$container->getParameter('documentationLink'),
            $getMemoryPeakUsageMock
        );
    }

    public function testExecute(): void
    {
        $commandTester = new CommandTester($this->command);
        $expectedTracking = new CoreCodeChangesData(
            'core:code:changes',
            0,
            4,
            28.57142857142857,
            self::MEMORY_PEAK_USAGE,
            true
        );

        $this->whenTrackIsCalled($expectedTracking);

        $startTime = microtime(true);
        $dir = self::$container->getParameter('integration_tests_files_path')
            . 'magentoInstallations/magento2.4.0-modified';
        $vanillaDir = self::$container->getParameter('integration_tests_files_path')
            . 'magentoInstallations/magento2.4.0';
        $commandResult = $commandTester->execute(
            [
                'dir' => $dir,
                'vanilla-dir' => $vanillaDir,
                '--output' => sprintf("%s/output/result.json", $this->fileSystemMock->url())
            ],
        );
        $endTime = microtime(true);

        $this->assertEquals($this->command::SUCCESS, $commandResult);

        $output = $commandTester->getDisplay();

        $this->assertEquals(
            $this->normalizeCliOutput(
                file_get_contents(
                    sprintf(
                        "%s/output/cli/%s.txt",
                        self::$container->getParameter('integration_tests_files_path'),
                        'compare_expected_output'
                    )
                ),
                [$dir, $vanillaDir]
            ),
            $this->normalizeCliOutput($output, [$dir, $vanillaDir])
        );

        $durationInSeconds = $this->calculateDurationInSeconds($startTime, $endTime);

        $this->assertLessThanOrEqual(
            self::EXPECTED_EXECUTION_TIME,
            $durationInSeconds,
            sprintf(
                'Core code changes execution time was %.2f that is greater than expected %.2f',
                $durationInSeconds,
                self::EXPECTED_EXECUTION_TIME
            )
        );

        $this->assertFileEquals(
            sprintf(
                "%s/output/json/core_code_changes_expected_output.json",
                self::$container->getParameter('integration_tests_files_path')
            ),
            sprintf(
                "%s/output/result.json",
                $this->fileSystemMock->url()
            )
        );
    }

    public function testExecuteForNonRootDirectory(): void
    {
        $commandTester = new CommandTester($this->command);

        $expectedTracking = new CoreCodeChangesData(
            'core:code:changes',
            0,
            1,
            100,
            self::MEMORY_PEAK_USAGE,
            true
        );

        $this->whenTrackIsCalled($expectedTracking);

        $startTime = microtime(true);
        $dir = self::$container->getParameter('integration_tests_files_path')
            . 'magentoInstallations/magento2.4.0-modified/generated';
        $vanillaDir = self::$container->getParameter('integration_tests_files_path')
            . 'magentoInstallations/magento2.4.0/generated';
        $commandResult = $commandTester->execute(
            [
                'dir' => $dir,
                'vanilla-dir' => $vanillaDir,
            ],
        );
        $endTime = microtime(true);

        $output = $commandTester->getDisplay();

        $this->assertEquals(
            $this->normalizeCliOutput(
                file_get_contents(
                    sprintf(
                        "%s/output/cli/%s.txt",
                        self::$container->getParameter('integration_tests_files_path'),
                        'compare_expected_output_generated'
                    )
                ),
                [$dir, $vanillaDir]
            ),
            $this->normalizeCliOutput($output, [$dir, $vanillaDir])
        );

        $this->assertEquals(1, substr_count($output, '[CRITICAL]'));

        $durationInSeconds = $this->calculateDurationInSeconds($startTime, $endTime);

        $this->assertLessThanOrEqual(
            self::EXPECTED_EXECUTION_TIME,
            $durationInSeconds,
            sprintf(
                'Core code changes execution time was %.2f that is greater than expected %.2f',
                $durationInSeconds,
                self::EXPECTED_EXECUTION_TIME
            )
        );

        $this->assertEquals($this->command::SUCCESS, $commandResult);

        $this->assertFileExists(
            sprintf(
                $this->outputPath,
                (new DateTime())->format('d_M_Y_h:i')
            )
        );
    }

    public function testExecuteWithNoVanillaDir(): void
    {
        $resultMock = $this->createMock(CommandExecution::class);
        $resultMock->expects($this->once())
            ->method('getExitCode')
            ->willReturn(1);
        $this->cmdServiceMock->expects($this->once())
            ->method('execCommand')
            ->with($this->stringStartsWith(sprintf(
                "composer create-project --repository-url=%s %s=%s",
                'https://repo.magento.com',
                'magento/project-enterprise-edition',
                '2.4.0',
            )))
            ->willReturn($resultMock);

        $this->command->setHelperSet(new HelperSet([new QuestionHelper()]));
        $commandTester = new CommandTester($this->command);

        $commandTester->execute(
            [
                'dir' => self::$container->getParameter('integration_tests_files_path')
                    . 'magentoInstallations/magento2.4.0'
            ],
        );
    }

    public function testExecuteWithNoVanillaDirRejectDownload(): void
    {
        $this->cmdServiceMock->expects($this->never())
            ->method('execCommand');

        $this->command->setHelperSet(new HelperSet([new QuestionHelper()]));
        $commandTester = new CommandTester($this->command);
        $commandTester->setInputs(['n']);

        $commandResult = $commandTester->execute(
            [
                'dir' => self::$container->getParameter('integration_tests_files_path')
                    . 'magentoInstallations/magento2.4.0'
            ],
        );

        $this->assertEquals($this->command::FAILURE, $commandResult);
    }

    private function calculateDurationInSeconds($startTime, $endTime): float
    {
        return round($endTime - $startTime, 2);
    }

    /**
     * @param CoreCodeChangesData $expectedTracking
     */
    private function whenTrackIsCalled(CoreCodeChangesData $expectedTracking): void
    {
        $this->trackerMock->expects($this->once())
            ->method('sendData')
            ->with($expectedTracking);
    }

    private function normalizeCliOutput(string $content, array $replacements): string
    {
        $replacements[] = '-';
        return preg_replace(
            '/ +\n/',
            "\n",
            str_replace($replacements, '', $content)
        );
    }
}
