<?php
/**
 * Copyright 2021 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace Sut\Tests\Integration\Infrastructure\Entrypoint\Command;

use DateInterval;
use DateTime;
use Sut\Infrastructure\Entrypoint\Command\RefactorCommand;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Tester\CommandTester;

class RefactorCommandTest extends KernelTestCase
{
    private const EXPECTED_EXECUTION_TIME = 9;

    private const REFACTOR_DIRECTORY = __DIR__ . '/../../../../../../var/refactor/';

    /**
     * @var CommandTester
     */
    private $commandTester;

    protected function setUp(): void
    {
        self::bootKernel();

        $this->copyFiles(
            self::$container->getParameter('integration_tests_files_path')
            . 'phpcbf/projects/project-with-phpcbf-issues/',
            self::REFACTOR_DIRECTORY
        );
        $this->commandTester = new CommandTester(self::$container->get(RefactorCommand::class));
    }

    /**
     * @param array $input
     * @param string $expectedOutput
     * @dataProvider executeProvider
     */
    public function testExecute(
        array $input,
        string $expectedOutput
    ): void {
        if (isset($input['path'])) {
            if ($input['path']  === 'project-with-phpcbf-issues') {
                $input['path'] = self::REFACTOR_DIRECTORY;
            } else {
                $input['path'] = self::$container->getParameter('integration_tests_files_path')
                    . 'phpcbf/projects/' . $input['path'];
            }
        }
        $start = new DateTime();
        $result = $this->commandTester->execute($input);
        $end = new DateTime();

        $this->assertEquals(Command::SUCCESS, $result, 'Command returned not success (0) exit code.');
        $this->assertOutput($expectedOutput);

        $durationInSeconds = $this->intervalToSeconds($end->diff($start));

        $this->assertLessThanOrEqual(
            self::EXPECTED_EXECUTION_TIME,
            $durationInSeconds,
            sprintf(
                'Refactor execution time was %.2f that is greater than expected %.2f',
                $durationInSeconds,
                self::EXPECTED_EXECUTION_TIME
            )
        );
    }

    /**
     * @return array[]
     */
    public function executeProvider(): array
    {
        return [
            'no_issues' => [
                [
                    'path' => 'project-without-phpcbf-issues'
                ],
                'No fixable errors were found'
            ],
            'positive' => [
                [
                    'path' => 'project-with-phpcbf-issues'
                ],
                'A TOTAL OF 3 ERRORS WERE FIXED IN 3 FILES'
            ]
        ];
    }

    /**
     * @param string $expected
     */
    private function assertOutput(string $expected): void
    {
        $this->assertTrue(
            strpos(
                $this->commandTester->getDisplay(),
                $expected,
            ) !== false
        );
    }

    /**
     * @param DateInterval $interval
     * @return float
     */
    private function intervalToSeconds(DateInterval $interval): float
    {
        return round(
            $interval->days * 86400 + $interval->h * 3600 + $interval->i * 60 + $interval->s + $interval->f,
            2
        );
    }

    /**
     * @param string $src
     * @param string $dst
     */
    private function copyFiles(string $src, string $dst): void
    {
        $dir = opendir($src);
        //phpcs:ignore Generic.PHP.NoSilencedErrors
        @mkdir($dst);
        while (false !== ($file = readdir($dir))) {
            if (($file != '.') && ( $file != '..' )) {
                if (is_dir($src . '/' . $file)) {
                    $this->copyFiles($src . '/' . $file, $dst . '/' . $file);
                } else {
                    copy($src . '/' . $file, $dst . '/' . $file);
                }
            }
        }
        closedir($dir);
    }
}
