<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace Sut\Tests\Integration\Infrastructure\Entrypoint\Command;

use Sut\Infrastructure\Entrypoint\Command\DbSchemaDiffCommand;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Tester\CommandTester;

class DbSchemaDiffCommandTest extends KernelTestCase
{

    /**
     * @var CommandTester
     */
    private $commandTester;

    protected function setUp(): void
    {
        self::bootKernel();
        $this->commandTester = new CommandTester(
            new DbSchemaDiffCommand(self::$container->getParameter('documentationLink'))
        );
    }

    /**
     * @param array $input
     * @param string[] $expectedMessages
     * @dataProvider executeProvider
     */
    public function testExecute(array $input, array $expectedMessages): void
    {
        $result = $this->commandTester->execute($input);

        $this->assertEquals(
            Command::SUCCESS,
            $result,
            sprintf(
                "Command returned not success (0) exit code.\nDisplay: %s",
                $this->commandTester->getDisplay(),
            )
        );

        $output = $this->commandTester->getDisplay();

        foreach ($expectedMessages as $message) {
            $this->assertStringContainsString($message, $output);
        }
    }

    /**
     * @return array[]
     */
    public function executeProvider(): array
    {
        return [
            [
                [
                    'current-version' => '2.4.4',
                    'target-version' => '2.4.5'
                ],
                [
                    'Table salesrule_label constraint SALESRULE_LABEL_RULE_ID_STORE_ID disabled'
                    . ' is present only in version 2.4.5',
                    'Table magento_catalogpermissions_index_product_replica constraint'
                    . ' MAGENTO_CATPERMISSIONS_IDX_PRD_PRD_ID_STORE_ID_CSTR_GROUP_ID type value is different.'
                    . ' 2.4.4: "primary", 2.4.5: "unique"'
                ]
            ],
            [
                [
                'current-version' => '2.3.7-p2',
                'target-version' => '2.3.7-p3'
                ],
                [
                    'Table oauth_consumer column secret length value is different. 2.3.7-p2: "32", 2.3.7-p3: "128"',
                    'Table oauth_token column secret length value is different. 2.3.7-p2: "32", 2.3.7-p3: "128"'
                ]
            ]
        ];
    }
}
