<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
namespace Sut\Tests\Unit\Infrastructure\GraphQl;

use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use RuntimeException;
use Sut\Domain\Cmd\CmdServiceInterface;
use Sut\Domain\Cmd\CommandExecution;
use Sut\Domain\Issue\DTO\Issue;
use Sut\Domain\Issue\DTO\IssueLevel;
use Sut\Domain\Issue\IssueFactory;
use Sut\Infrastructure\GraphQl\GraphQl;

class GraphQlTest extends TestCase
{
    /**
     * @var MockObject|CmdServiceInterface
     */
    private $cmdServiceMock;

    /**
     * @var array
     */
    private $issuesConfig;

    public function setUp(): void
    {
        parent::setUp();
        $this->cmdServiceMock = $this->getMockBuilder(CmdServiceInterface::class)->getMock();
        $this->issuesConfig = [
            'issues' =>
                [
                    1234 =>
                        [
                            'level' => IssueLevel::ERROR,
                            'type' => 'TYPE_REMOVED',
                        ],
                ]
        ];
    }

    public function testGetSchemaDiffWhenExceptionIsThrown()
    {
        $graphQl = new GraphQl($this->cmdServiceMock, new IssueFactory($this->issuesConfig));
        $this->cmdServiceMock->expects($this->once())
            ->method('execCommand')
            ->with("node /test/index.js https://test1/graphql https://test2/graphql 2>&1")
            ->willReturn(new CommandExecution('', [0 => 'Some error'], 1));

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('Some error');

        $graphQl->getSchemaDiff('https://test1/graphql', 'https://test2/graphql', '/test/index.js');
    }

    public function testGetSchemaDiffEmpty()
    {
        $graphQl = new GraphQl($this->cmdServiceMock, new IssueFactory($this->issuesConfig));
        $this->cmdServiceMock->expects($this->once())
            ->method('execCommand')
            ->with("node /test/index.js https://test1/graphql https://test2/graphql 2>&1")
            ->willReturn(new CommandExecution('', [0 => '[]'], 0));

        $schemaDiff = $graphQl->getSchemaDiff('https://test1/graphql', 'https://test2/graphql', '/test/index.js');

        $this->assertEmpty($schemaDiff);
    }

    public function testGetSchemaDiff()
    {
        $graphQl = new GraphQl($this->cmdServiceMock, new IssueFactory($this->issuesConfig));
        $this->cmdServiceMock->expects($this->once())
            ->method('execCommand')
            ->with("node /test/index.js https://test1/graphql https://test2/graphql 2>&1")
            ->willReturn(
                new CommandExecution(
                    '',
                    [
                        0 => '[{"severity":"' . IssueLevel::ERROR . '",' .
                            '"type":"TYPE_REMOVED","description":"FixedProductTax was removed."}]'
                    ],
                    0
                )
            );

        $schemaDiff = $graphQl->getSchemaDiff('https://test1/graphql', 'https://test2/graphql', '/test/index.js');

        $this->assertEquals(
            [new Issue(IssueLevel::ERROR, 'FixedProductTax was removed.', 1234, 0, 'TYPE_REMOVED', '', 'php')],
            $schemaDiff
        );
    }
}
