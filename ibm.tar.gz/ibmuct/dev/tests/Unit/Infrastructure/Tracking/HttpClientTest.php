<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
namespace Sut\Tests\Unit\Infrastructure\Tracking;

use GuzzleHttp\ClientInterface;
use GuzzleHttp\Psr7\Response;
use PHPUnit\Framework\TestCase;
use Sut\Domain\Tracking\HttpResponse;
use Sut\Infrastructure\Tracking\HttpClient;

class HttpClientTest extends TestCase
{
    /**
     * @var \PHPUnit\Framework\MockObject\MockBuilder|ClientInterface
     */
    private $client;

    /**
     * @var HttpClient
     */
    private $httpClient;

    protected function setUp(): void
    {
        parent::setUp();
        $this->client = $this->getMockBuilder(ClientInterface::class)->getMock();
        $this->httpClient = new HttpClient($this->client);
    }

    public function testRequest()
    {
        $clientHttpResponse = new Response(200, [], "Test body");
        $expectedHttpClientResponse = new HttpResponse(200, "Test body");
        $this->client->expects($this->once())
            ->method('request')
            ->with("POST", "http://test.com", ["headers" => ["h1" => "value1"], "body" => '{"param" : "value"}'])
            ->willReturn($clientHttpResponse);

        $this->assertEquals(
            $expectedHttpClientResponse,
            $this->httpClient->request("POST", "http://test.com", ["h1" => "value1"], '{"param" : "value"}')
        );
    }
}
