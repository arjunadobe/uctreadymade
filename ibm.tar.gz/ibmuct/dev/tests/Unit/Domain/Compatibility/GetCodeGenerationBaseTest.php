<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
declare(strict_types=1);

namespace Sut\Tests\Unit\Domain\Compatibility;

use PHPUnit\Framework\TestCase;
use Sut\Domain\Compatibility\GetCodeGenerationBase;

class GetCodeGenerationBaseTest extends TestCase
{
    /**
     * @var GetCodeGenerationBase
     */
    private $getCodeGenerationBase;

    public function setUp(): void
    {
        $this->getCodeGenerationBase = new GetCodeGenerationBase();
    }

    /**
     * @param string $input
     * @param string $expectedResult
     * @dataProvider cases
     */
    public function testExecute(string $input, string $expectedResult) : void
    {
        $result = $this->getCodeGenerationBase->execute($input);
        $this->assertEquals($expectedResult, $result);
    }

    /**
     * @return string[][]
     */
    public function cases(): array
    {
        return [
            ['\Magento\Customer\Model\CustomerExtensionInterfaceFactory', '\Magento\Customer\Model\CustomerInterface'],
            ['\Magento\Customer\Model\CustomerFactory', '\Magento\Customer\Model\Customer'],
            ['\Magento\Customer\Model\CustomerMapper', '\Magento\Customer\Model\Customer'],
            ['\Magento\Customer\Model\CustomerPersistor', '\Magento\Customer\Model\Customer'],
            ['\Magento\Customer\Model\CustomerConverter', '\Magento\Customer\Model\Customer'],
            ['\Magento\Tax\Api\Data\AppliedTaxRateExtension', '\Magento\Tax\Api\Data\AppliedTaxRateInterface'],
            ['\Magento\Customer\Model\CustomerRemote', '\Magento\Customer\Model\Customer'],
            ['Magento\Backend\App\Request\PathInfoProcessor\Proxy', 'Magento\Backend\App\Request\PathInfoProcessor'],
            ['Magento\Backend\App\Request\PathInfoProcessor\Interceptor',
                'Magento\Backend\App\Request\PathInfoProcessor'],
            ['Magento\Backend\App\Request\PathInfoProcessor\Logger', 'Magento\Backend\App\Request\PathInfoProcessor'],
            ['Magento\Catalog\Api\Data\ProductLinkInterface\Repository',
                'Magento\Catalog\Api\Data\ProductLinkInterface'],
            ['Magento\Backend\App\Request\PathInfoProcessor\SearchResults',
                'Magento\Backend\App\Request\PathInfoProcessor'],
            ['Magento\Backend\App\Request\PathInfoProcessor\ProxyDeferred',
                'Magento\Backend\App\Request\PathInfoProcessor'],
            ['Magento\Tax\Api\Data\QuoteDetailsItemExtensionFactory',
                'Magento\Tax\Api\Data\QuoteDetailsItemInterface'],
            ['Magento\Tax\Api\Data\QuoteDetailsItemExtensionInterface',
                'Magento\Tax\Api\Data\QuoteDetailsItemInterface'],
        ];
    }
}
