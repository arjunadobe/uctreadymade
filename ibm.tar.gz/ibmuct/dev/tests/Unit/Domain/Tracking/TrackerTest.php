<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
namespace Sut\Tests\Unit\Domain\Tracking;

use PHPUnit\Framework\TestCase;
use Sut\Domain\Time\TimerInterface;
use Sut\Domain\Tracking\HttpClientInterface;
use Sut\Domain\Tracking\HttpResponse;
use Sut\Domain\Tracking\Track\CoreCodeChangesData;
use Sut\Domain\Tracking\Track\UpdateCheckData;
use Sut\Domain\Tracking\Tracker;

class TrackerTest extends TestCase
{
    private const TRACK_URL = 'http://suttracker.com';

    /**
     * @var \PHPUnit\Framework\MockObject\MockObject|HttpClientInterface
     */
    private $httpClient;

    /**
     * @var \PHPUnit\Framework\MockObject\MockObject|TimerInterface
     */
    private $timer;

    /**
     * @var Tracker|HttpClientInterface
     */
    private $tracker;

    /**
     * @var int
     */
    private const CURRENT_TIME = 1605006578;

    public function setUp(): void
    {
        parent::setUp();
        $this->httpClient = $this->getMockBuilder(HttpClientInterface::class)->getMock();
        $this->timer = $this->getMockBuilder(TimerInterface::class)->getMock();

        $this->tracker = new Tracker(
            $this->httpClient,
            $this->timer,
            self::TRACK_URL
        );
    }

    public function testTrackWhenExceptionIsThrown()
    {
        $this->whenTimerIsCalled();

        $this->httpClient->expects($this->once())
            ->method('request')
            ->willThrowException(new \Exception());

        $this->assertNull(
            $this->tracker->sendData(
                new UpdateCheckData(
                    1,
                    '2.3',
                    '2.4',
                    117.73756885528564
                )
            )
        );
    }

    /**
     * @dataProvider trackOkDataProvider
     */
    public function testTrackOk($track): void
    {
        $this->whenTimerIsCalled();

        $responseOk = new HttpResponse(200, 'Key sut_executed value 1.000000');
        $jsonToTrack = $track->serialize();
        $this->httpClient->expects($this->once())
            ->method('request')
            ->with(
                'POST',
                'http://suttracker.com',
                $this->anything(),
                $jsonToTrack
            )
            ->willReturn($responseOk);

        $this->assertJson($jsonToTrack);

        $this->assertEquals($responseOk, $this->tracker->sendData($track));
    }

    private function whenTimerIsCalled(): void
    {
        $this->timer->expects($this->once())
            ->method('time')
            ->willReturn(self::CURRENT_TIME);
    }

    public function trackOkDataProvider(): array
    {
        return [
            [
                new UpdateCheckData(
                    1,
                    '2.3',
                    '2.4',
                    117.73756885528564
                )
            ],
            [
                new CoreCodeChangesData(
                    'core:code:changes',
                    1,
                    2,
                    '50',
                    117.73756885528564
                )
            ],
        ];
    }
}
