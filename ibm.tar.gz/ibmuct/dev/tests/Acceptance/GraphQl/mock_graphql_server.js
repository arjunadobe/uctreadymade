/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */

import express from 'express';
import { graphqlHTTP } from 'express-graphql';
import { buildSchema } from 'graphql';
import fs from 'fs';
import { dirname } from 'path';
import { fileURLToPath } from 'url';

const oldGraphqlSchemaFile = fs.readFileSync(
        dirname(fileURLToPath(import.meta.url)) + '/../_files/graphql_schemas/old_graphql_schema.graphqls',
        'utf-8'
    ),
    newGraphqlSchemaFile = fs.readFileSync(
        dirname(fileURLToPath(import.meta.url)) + '/../_files/graphql_schemas/new_graphql_schema.graphqls',
        'utf-8'
    ),
    oldGraphqlSchema = buildSchema(oldGraphqlSchemaFile),
    newGraphqlSchema = buildSchema(newGraphqlSchemaFile),
    app = express(),
    newApp = express();

app.use('/graphql', graphqlHTTP({
    schema: oldGraphqlSchema,
    graphiql: true
}));

app.listen(
    3000,

    /**
     * Callback to output the graphql schema url to the console
     */
    () => {
        console.info('Listening on http://localhost:3000/graphql');
    }
);

newApp.use('/graphql', graphqlHTTP({
    schema: newGraphqlSchema,
    graphiql: true
}));

newApp.listen(
    4000,

    /**
     * Callback to output the graphql schema url to the console
     */
    () => {
        console.info('Listening on http://localhost:4000/graphql');
    }
);
