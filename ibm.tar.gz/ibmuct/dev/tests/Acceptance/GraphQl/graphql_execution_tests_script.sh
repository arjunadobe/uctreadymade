#This script is to execute the acceptance tests for the graphql compare command
node dev/tests/Acceptance/GraphQl/mock_graphql_server.js 2>&1 & PID=$!
sleep 2
if ! vendor/bin/phpunit -c dev/tests/Acceptance/phpunit.xml.dist ;  then
  kill -9 $PID
  exit 1
fi
kill -9 $PID
