<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 *
 * NOTICE: Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying
 * it.
 */
namespace Sut\Tests\Acceptance\GraphQl;

use PHPUnit\Framework\TestCase;

class GraphQlCompareCommandTest extends TestCase
{
    private const EXPECTED_EXECUTION_TIME = 28.80;
    private const JSON_FILE_RESULT = '/result.json';

    /**
     * @var string
     */
    private $tmpPath;

    /**
     * @var string
     */
    private $defaultOutputPath;

    protected function setUp(): void
    {
        $this->tmpPath = dirname(__DIR__, 4) . '/var/tmp_test';
        $this->defaultOutputPath = dirname(__DIR__, 4) . '/var/output/';
    }

    protected function tearDown() :void
    {
        // phpcs:ignore Magento2.Security.InsecureFunction
        exec(sprintf('rm -rf %s', $this->tmpPath));
        // phpcs:ignore Magento2.Security.InsecureFunction
        exec(sprintf('rm -rf %s/*', $this->defaultOutputPath));
    }

    /**
     * @dataProvider graphQlCompareProvider
     */
    public function testGraphQLCompare(
        int $permissions,
        string $url1,
        string $url2,
        string $expectedOutputPath,
        ?string $expectedFilePath
    ) {
        if (!file_exists($this->tmpPath)) {
            mkdir($this->tmpPath, $permissions, true);
        }
        $jsonFileResult = $this->tmpPath . self::JSON_FILE_RESULT;

        $startTime = microtime(true);

        $commandResult = $this->runCommand($url1, $url2, $jsonFileResult);

        $endTime = microtime(true);

        $this->assertCliOutput($expectedOutputPath, $commandResult);
        $this->assertExportedJson($expectedFilePath, $jsonFileResult, $commandResult);
        $this->assertExecutionTime($startTime, $endTime);
    }

    /**
     * @dataProvider graphQlCompareProvider
     */
    public function testGraphQLCompareWithoutOutput(
        int $permissions,
        string $url1,
        string $url2,
        string $expectedOutputPath,
        ?string $expectedFilePath
    ) {
        if (!file_exists($this->tmpPath)) {
            mkdir($this->tmpPath, $permissions);
        }
        $jsonFileResult = $this->tmpPath . self::JSON_FILE_RESULT;

        $startTime = microtime(true);

        $commandResult = $this->runCommand($url1, $url2, '');

        $endTime = microtime(true);

        $this->assertCliOutput($expectedOutputPath, $commandResult);
        $this->assertFileDoesNotExist($jsonFileResult);

        $files = glob($this->defaultOutputPath . '*-results.json');

        $this->assertNotEmpty($files);

        $this->assertExecutionTime($startTime, $endTime);
    }

    public function graphQlCompareProvider(): array
    {
        return [
            [
                0777,
                GRAPHQL_URL_1,
                GRAPHQL_URL_2,
                '/output/graphql_command_output_with_errors.txt',
                '/output/graphql_schema_output_with_errors.json'
            ],
            [
                0777,
                GRAPHQL_URL_1,
                GRAPHQL_URL_1,
                '/output/graphql_command_output_no_errors.txt',
                '/output/graphql_schema_output_no_errors.json'
            ],
//            [
//                0444,
//                GRAPHQL_URL_1,
//                GRAPHQL_URL_1,
//                '/output/graphql_command_output_no_errors.txt',
//                null
//            ],
//            [
//                0444,
//                GRAPHQL_URL_1,
//                GRAPHQL_URL_2,
//                '/output/graphql_command_output_with_errors.txt',
//                null
//            ]
        ];
    }

    private function assertCliOutput(string $expectedOutputPath, string $output): void
    {
        $this->assertEquals(
            $this->removeRunningTimeAndSpaces(file_get_contents(dirname(__DIR__) . '/_files' . $expectedOutputPath)),
            $this->removeRunningTimeAndSpaces($output)
        );
    }

    private function assertExecutionTime(int $startTime, int $endTime): void
    {
        $durationInSeconds = round($endTime - $startTime, 2);

        $this->assertLessThanOrEqual(
            self::EXPECTED_EXECUTION_TIME,
            $durationInSeconds,
            sprintf(
                'GraphQL schema check execution time was %.2f that is greater than expected %.2f',
                $durationInSeconds,
                self::EXPECTED_EXECUTION_TIME
            )
        );
    }

    private function assertExportedJson($expectedFile, $resultFile, $commandResult): void
    {
        if ($expectedFile) {
            $this->assertFileEquals(
                dirname(__DIR__) . '/_files' . $expectedFile,
                $resultFile
            );
        } else {
            $this->assertFileDoesNotExist($resultFile);
            $this->assertDirectoryDoesNotExist($this->tmpPath . '/tmp');
            $this->assertStringContainsString('Could not create the exported file', $commandResult);
        }
    }

    private function removeRunningTimeAndSpaces(string $content): string
    {
        $lines = explode("\n", $content);
        $resultLines = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if (strpos($line, 'Running time') === false) {
                $resultLines[] = $line;
            }
        }
        return implode("\n", $resultLines);
    }

    private function runCommand(string $url1, string $url2, string $outputFile): string
    {
        // phpcs:ignore Magento2.Security.InsecureFunction
        return (string) shell_exec(
            sprintf(
                '%s graphql:compare %s %s --output %s 2>&1',
                dirname(__DIR__, 4) . '/bin/uct',
                $url1,
                $url2,
                $outputFile
            )
        );
    }
}
