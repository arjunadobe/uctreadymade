<?php

  $content = file_get_contents('vendor/magento/magento-coding-standard/Magento2/ruleset.xml');
  $xml = new SimpleXMLElement($content);
  $results = $xml->xpath('/ruleset/rule');
  $id = 5001;
foreach ($results as $result) {
    echo sprintf("            %d: \n", $id++);
    echo sprintf("                type: %s \n", $result->attributes()['ref']);
    echo "                level: 2 \n";
}
