# Base CI for SUT project (WIP)

## Goals

The focus for this CI is provide the necessary pipelines to automate the common repository tasks, keeping as aligned as possible with the Adobe Security policies.
Things to take into account:

* Use clean Docker images     - [x]  
* Use Adobe repositories      - [x]
* Maintain passwords on Vault - [x]

* Direct communication between Github and Corporate Jenkins are not possible, so we will configure a poll system that will check the PR requests and trigger the **Pull Requests test** job

## Defined Jobs

### Jenkinsfile.test

This Job is focused to running the unit test over the main branch. This is adhoc. 

### Jenkinsfile.check_PR

This Job is meant to be run into a multibranch pipeline in order to poll for changes and execute the test when something comes up. Is mandatory configure the github with branch protection for binding github repo and Jenkins job.

## Defined Dockerfiles

To keep the Jenkins server as more standard as we could, instead of installing PHP and other necessary stuff, we will build and run the test with a Docker, based on an image built with the Adobe base tools and libraries. The Dockerfile is the **Dockerfile.jenkins_worker**

## Ugly details

The current way to request the corporate github repository is using ssh. This is a messy stuff because the +*.ssh** folder must be on the Jenkins running user home directory. We managed that on the stage "composer install", recovering the private key from Vault and saving it on the **jnknsprd** home user (/apps/home/jnknsprd/.ssh/id_rsa")

## Secrets needed

Here comes the list of secrets needed. All of them are stored on the Vault safe storage (https://vault.dev.or1.adobe.net/ui/vault/secrets/dx_iberian_lynx/list/sut/)

| secret         | fields        | description  | 
|----------------|---------------|--------------|
| x_iberian_lynx/sut/github_credentials | user, api_token | Here are the credentials for the github access. We use the generic user magesut |
| dx_iberian_lynx/sut/magesut_composer_credentials| key_public, key_private | Marketplace credentials for the generic user magesut |
| dx_iberian_lynx/sut/corp_git_credentials| username, token, private_key | These are the crendentials for the user magesut for working with the Corporate Github |

