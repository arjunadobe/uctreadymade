bin/package
composer clearcache
composer create-project --repository=ops/packages.json magento/upgrade-compatibility-tool var/uct-project
chmod -R 777 var
var/uct-project/bin/uct upgrade:check dev/tests/Integration/_files/compatibility/projects/magento-fake-module-with-errors -c 2.4.2 > var/result.txt 2>&1
grep "Files that require update" var/result.txt | xargs > var/actual.txt
grep "Files that require update" dev/tests/Integration/_files/compatibility/output/cli/check_expected_output.txt | xargs > var/expected.txt
diff var/actual.txt var/expected.txt
